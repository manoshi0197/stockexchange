import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor() { }

// Sign in
signIn(username, password){
  // call api here
  // return observable
}

}
