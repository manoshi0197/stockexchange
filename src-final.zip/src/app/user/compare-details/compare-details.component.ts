import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'compare-details',
  templateUrl: './compare-details.component.html',
  styleUrls: ['./compare-details.component.scss']
})
export class CompareDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
