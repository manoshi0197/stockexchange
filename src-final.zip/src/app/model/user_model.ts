export interface User {
    userName: string;
    password: string;
    email: string;
    mobile: number;
    confirmed: Boolean;
  }
  